/**
 * gemini_bridge.js
 * ══════════════════════════════════════════════════════════════════════════════
 * DeepDive — LLM bridge module.
 *
 * DESIGN
 * ──────
 * This module is intentionally provider-agnostic.  All provider-specific
 * details (endpoint URL, model name, request schema, key header) are isolated
 * in the PROVIDERS config object at the top of the file.  Switching providers
 * is a single-line change to ACTIVE_PROVIDER.
 *
 * SUPPORTED PROVIDERS
 * ───────────────────
 *   "groq"       — Groq Cloud (free, fast, Llama 3)       https://console.groq.com
 *   "openrouter" — OpenRouter (free models available)      https://openrouter.ai
 *   "ollama"     — Local Ollama (completely free, offline) http://localhost:11434
 *
 * KEY MANAGEMENT
 * ──────────────
 * The API key is fetched at runtime from the DeepDive local bridge server
 * (GET http://localhost:7432/gemini_key).  The key is stored in module memory
 * only — never in localStorage, never in the DOM.  For Ollama no key is needed.
 *
 * RESPONSIBILITIES
 * ────────────────
 *   • Fetch the API key from the local server on page load.
 *   • Send chat messages to the active LLM provider.
 *   • Run the onboarding conversation that builds a DAG from user answers.
 *   • Convert a user text description directly to a DAG JSON object.
 *   • Request an emoji for a node name (called automatically on node naming).
 * ══════════════════════════════════════════════════════════════════════════════
 */

// ─────────────────────────────────────────────────────────────────────────────
// ██  PROVIDER CONFIGURATION  ─────────────────────────────────────────────────
// ─────────────────────────────────────────────────────────────────────────────
// To switch providers, change ACTIVE_PROVIDER to one of the keys below.
// Nothing else needs to change.

/** The provider to use. Change this one line to switch LLM providers. */
const ACTIVE_PROVIDER = "groq";

/**
 * Provider registry.
 * Each entry defines everything needed to talk to that provider's API.
 *
 * Fields:
 *   label        — Human-readable name shown in the UI
 *   baseUrl      — Base URL for the chat completions endpoint
 *   model        — Default model name to use
 *   keyHeader    — HTTP header used to pass the API key ("" = no key needed)
 *   keyPrefix    — String prepended to the key in the header (e.g. "Bearer ")
 *   needsKey     — Whether an API key is required (false for Ollama)
 *   buildBody    — Function(messages, systemPrompt) → request body object
 *   extractText  — Function(responseJson) → assistant reply string
 */
const PROVIDERS = {

  groq: {
    label:     "Groq · Llama 3",
    baseUrl:   "https://api.groq.com/openai/v1/chat/completions",
    model:     "llama3-8b-8192",
    keyHeader: "Authorization",
    keyPrefix: "Bearer ",
    needsKey:  true,
    buildBody(messages, systemPrompt) {
      return {
        model: this.model,
        messages: [
          { role: "system", content: systemPrompt },
          ...messages,
        ],
        temperature: 0.4,
        max_tokens:  2048,
        stream:      false,
      };
    },
    extractText(data) {
      return data?.choices?.[0]?.message?.content ?? "";
    },
  },

  openrouter: {
    label:     "OpenRouter · Mistral 7B",
    baseUrl:   "https://openrouter.ai/api/v1/chat/completions",
    model:     "mistralai/mistral-7b-instruct:free",
    keyHeader: "Authorization",
    keyPrefix: "Bearer ",
    needsKey:  true,
    buildBody(messages, systemPrompt) {
      return {
        model: this.model,
        messages: [
          { role: "system", content: systemPrompt },
          ...messages,
        ],
        temperature: 0.4,
        max_tokens:  2048,
      };
    },
    extractText(data) {
      return data?.choices?.[0]?.message?.content ?? "";
    },
  },

  ollama: {
    label:     "Ollama · Local",
    baseUrl:   "http://localhost:11434/v1/chat/completions",
    model:     "llama3",
    keyHeader: "",
    keyPrefix: "",
    needsKey:  false,
    buildBody(messages, systemPrompt) {
      return {
        model: this.model,
        messages: [
          { role: "system", content: systemPrompt },
          ...messages,
        ],
        stream: false,
      };
    },
    extractText(data) {
      return data?.choices?.[0]?.message?.content ?? "";
    },
  },
};

// ─────────────────────────────────────────────────────────────────────────────
// Local bridge server URL — must match local_server.py DEFAULT_PORT
// ─────────────────────────────────────────────────────────────────────────────
const LOCAL_SERVER_URL = "http://localhost:7432";

// ─────────────────────────────────────────────────────────────────────────────
// System prompts
// ─────────────────────────────────────────────────────────────────────────────

/**
 * System prompt for the onboarding conversation.
 * The LLM acts as a friendly guide that asks one question at a time until it
 * has enough context to build a DAG, then emits the graph JSON.
 */
const ONBOARDING_SYSTEM_PROMPT = `
You are DeepDive's onboarding assistant. Help the user build a causal DAG by
having a warm, focused conversation. Ask ONE question at a time.

FLOW
────
1. Greet the user and ask what they want to model or analyse.
2. Ask clarifying questions (one at a time, max 4-5 total) to understand:
   - The main outcome variable they care about
   - What factors cause or influence it
   - Any intermediate variables
   - Whether variables are binary, categorical, counts, or continuous
3. When you have enough info (usually 4-10 nodes worth), say exactly:
   "I have enough to build your DAG! Here it is:"
   Then on the VERY NEXT LINE emit ONLY this (no markdown, no extra text):
   DEEPDIVE_DAG_JSON:{"nodes":[...],"edges":[...],"root_ids":[...],"leaf_ids":[...],"parents":{...},"var_types":{...},"levels":{}}

NODE SCHEMA
───────────
{"id":<int>,"name":<string max 14 chars no spaces>,"emoji":<single emoji>,"x":0,"y":0,"var_type":<"continuous"|"binary"|"ordinal"|"categorical"|"count">}

RULES
─────
- DAG must be acyclic (no cycles, no self-loops).
- Every node needs a unique integer id (1-indexed) and a short name.
- Pick memorable, accurate emoji for every node — this is the fun part.
- Keep names under 14 characters: use snake_case or CamelCase.
- x and y must be 0; the frontend handles layout.
- Be warm and encouraging. This is a creative, exploratory tool.
`.trim();

/**
 * System prompt for the general chat assistant (post-onboarding).
 */
const CHAT_SYSTEM_PROMPT = `
You are DeepDive's causal modelling assistant. The user has built (or is building)
a causal DAG. Help them refine it, understand it, or answer questions about
causal reasoning.

If they ask you to build or modify the DAG, emit the updated graph on its own line:
DEEPDIVE_DAG_JSON:{"nodes":[...],"edges":[...],"root_ids":[...],"leaf_ids":[...],"parents":{...},"var_types":{...},"levels":{}}

Keep replies concise and conversational. You are a helpful colleague, not a textbook.
`.trim();

/**
 * System prompt for single-shot text-to-DAG conversion.
 */
const TEXT_TO_DAG_SYSTEM_PROMPT = `
Convert the user's description into a causal DAG. Return ONLY this line, nothing else:
DEEPDIVE_DAG_JSON:{"nodes":[...],"edges":[...],"root_ids":[...],"leaf_ids":[...],"parents":{...},"var_types":{...},"levels":{}}

Node schema: {"id":<int>,"name":<string max 14 chars>,"emoji":<single emoji>,"x":0,"y":0,"var_type":<"continuous"|"binary"|"ordinal"|"categorical"|"count">}
Rules: DAG must be acyclic. 4-12 nodes. Memorable emoji for every node. No markdown, no explanation.
`.trim();


// ─────────────────────────────────────────────────────────────────────────────
// Module state
// ─────────────────────────────────────────────────────────────────────────────

let _apiKey    = null;
let _keyStatus = "unknown"; // "ok" | "missing" | "error" | "unknown"

/** Resolved provider config (shortcut). */
const _provider = PROVIDERS[ACTIVE_PROVIDER];


// ─────────────────────────────────────────────────────────────────────────────
// Key management
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Fetch the API key from the local bridge server.
 * For Ollama (needsKey=false) this resolves immediately.
 *
 * @param {function} onStatus  callback(message, type)
 *                             type: "ok" | "warn" | "error" | "info"
 */
async function fetchApiKey(onStatus) {
  if (!_provider.needsKey) {
    _apiKey    = "no-key-needed";
    _keyStatus = "ok";
    onStatus(`Provider: ${_provider.label} — no API key needed`, "ok");
    return;
  }

  onStatus("Connecting to DeepDive local server…", "info");

  try {
    const res = await fetch(`${LOCAL_SERVER_URL}/gemini_key`, {
      signal: AbortSignal.timeout(3000),
    });

    if (res.ok) {
      const data = await res.json();
      _apiKey    = data.key;
      _keyStatus = "ok";
      onStatus(`Connected ✓  Provider: ${_provider.label}`, "ok");
    } else {
      const err  = await res.json().catch(() => ({}));
      _keyStatus = "missing";
      onStatus(
        `API key not set. ${err.hint || "Set the key env var and restart local_server.py."}`,
        "warn"
      );
    }
  } catch {
    _keyStatus = "error";
    onStatus(
      "Local server unreachable — start local_server.py to enable LLM features.",
      "error"
    );
  }
}

/** Returns true if we have a working API key and can call the LLM. */
function llmReady() {
  return _keyStatus === "ok" && !!_apiKey;
}


// ─────────────────────────────────────────────────────────────────────────────
// Core LLM call
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Send messages to the active provider and return the assistant's reply.
 *
 * @param {Array}  messages      - [{role, content}, ...]
 * @param {string} systemPrompt
 * @returns {Promise<string|null>}
 */
async function _callLLM(messages, systemPrompt) {
  if (!llmReady()) return null;

  const headers = { "Content-Type": "application/json" };
  if (_provider.needsKey && _provider.keyHeader) {
    headers[_provider.keyHeader] = `${_provider.keyPrefix}${_apiKey}`;
  }

  try {
    const res = await fetch(_provider.baseUrl, {
      method:  "POST",
      headers,
      body:    JSON.stringify(_provider.buildBody(messages, systemPrompt)),
      signal:  AbortSignal.timeout(30_000),
    });

    if (!res.ok) {
      console.error(`LLM API ${res.status}:`, await res.text());
      return null;
    }

    return _provider.extractText(await res.json()) || null;

  } catch (e) {
    console.error("LLM fetch error:", e);
    return null;
  }
}


// ─────────────────────────────────────────────────────────────────────────────
// DAG JSON extraction
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Find the DEEPDIVE_DAG_JSON: marker in an LLM reply and extract the graph.
 * Returns { graph, cleanText } where cleanText is the reply with the JSON
 * line removed so only prose appears in the chat bubble.
 */
function extractDAGFromReply(replyText) {
  const MARKER = "DEEPDIVE_DAG_JSON:";
  const idx    = replyText.indexOf(MARKER);

  if (idx === -1) return { graph: null, cleanText: replyText };

  // JSON runs from marker to the first newline
  const jsonStr   = replyText.slice(idx + MARKER.length).split("\n")[0].trim();
  const cleanText = replyText.slice(0, idx).trim();

  try {
    return { graph: JSON.parse(jsonStr), cleanText };
  } catch (e) {
    console.error("DAG JSON parse failed:", jsonStr, e);
    return { graph: null, cleanText: replyText };
  }
}


// ─────────────────────────────────────────────────────────────────────────────
// Onboarding conversation
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Send one turn of the guided onboarding conversation.
 * The caller owns and passes the history array; this function appends to it.
 *
 * @param {Array}  history      - conversation history (mutated in place)
 * @param {string} userMessage
 * @returns {Promise<{ reply: string, graph: object|null }>}
 */
async function onboardingTurn(history, userMessage) {
  history.push({ role: "user", content: userMessage });

  const raw = await _callLLM(history, ONBOARDING_SYSTEM_PROMPT);

  if (!raw) {
    const fallback = "Sorry, I couldn't reach the LLM. Check that local_server.py is running.";
    history.push({ role: "assistant", content: fallback });
    return { reply: fallback, graph: null };
  }

  const { graph, cleanText } = extractDAGFromReply(raw);
  history.push({ role: "assistant", content: cleanText || raw });

  return { reply: cleanText || raw, graph };
}


// ─────────────────────────────────────────────────────────────────────────────
// General chat
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Send one turn of the general post-onboarding chat.
 *
 * @param {Array}  history
 * @param {string} userMessage
 * @returns {Promise<{ reply: string, graph: object|null }>}
 */
async function chatTurn(history, userMessage) {
  history.push({ role: "user", content: userMessage });

  const raw = await _callLLM(history, CHAT_SYSTEM_PROMPT);

  if (!raw) {
    const fallback = "LLM unavailable. Is local_server.py running?";
    history.push({ role: "assistant", content: fallback });
    return { reply: fallback, graph: null };
  }

  const { graph, cleanText } = extractDAGFromReply(raw);
  history.push({ role: "assistant", content: cleanText || raw });

  return { reply: cleanText || raw, graph };
}


// ─────────────────────────────────────────────────────────────────────────────
// Single-shot text → DAG
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Convert a plain-English description to a DAG in one LLM call.
 *
 * @param {string}   text
 * @param {function} onProgress  callback(message, type)
 * @returns {Promise<object|null>}
 */
async function textToDAG(text, onProgress) {
  if (!llmReady()) { onProgress("LLM not ready.", "error"); return null; }
  if (!text.trim()) { onProgress("Enter a description first.", "warn"); return null; }

  onProgress("Generating DAG…", "info");

  const raw = await _callLLM([{ role: "user", content: text }], TEXT_TO_DAG_SYSTEM_PROMPT);

  if (!raw) { onProgress("No response from LLM. Try again.", "error"); return null; }

  const { graph } = extractDAGFromReply(raw);
  if (!graph) {
    onProgress("Could not parse a DAG from the response. Try rephrasing.", "warn");
    return null;
  }

  onProgress(`DAG generated: ${graph.nodes?.length} nodes ✓`, "ok");
  return graph;
}


// ─────────────────────────────────────────────────────────────────────────────
// Automatic emoji assignment
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Ask the LLM for a single emoji representing a node concept.
 * Called automatically when a node is named — not triggered by the user.
 * Falls back to a generic symbol if the LLM is unavailable.
 *
 * @param {string} nodeName
 * @returns {Promise<string>}  a single emoji character
 */
async function autoEmoji(nodeName) {
  if (!llmReady()) return "◈";   // silent fallback — LLM is optional

  const raw = await _callLLM(
    [{
      role: "user",
      content:
        `Pick exactly one emoji that visually represents "${nodeName}" in a causal model. ` +
        `Return ONLY the single emoji — no text, no punctuation, nothing else.`,
    }],
    "You are an emoji selector. Return exactly one emoji character and nothing else."
  );

  if (!raw) return "◈";

  // Extract the first proper emoji from the response, guarding against stray text
  const match = raw.trim().match(/\p{Emoji_Presentation}|\p{Emoji}\uFE0F/u);
  return match ? match[0] : (raw.trim().slice(0, 2) || "◈");
}


// ─────────────────────────────────────────────────────────────────────────────
// Exports (plain globals — no bundler)
// ─────────────────────────────────────────────────────────────────────────────

window.DeepDiveLLM = {
  fetchApiKey,
  llmReady,
  onboardingTurn,
  chatTurn,
  textToDAG,
  autoEmoji,
  extractDAGFromReply,
  providerLabel:    _provider.label,
  LOCAL_SERVER_URL,
};
